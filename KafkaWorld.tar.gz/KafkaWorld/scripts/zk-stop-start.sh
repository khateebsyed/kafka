#!/bin/bash
~/confluent-7.5.0/bin/zookeeper-server-stop
sleep 10;
~/confluent-7.5.0/bin/zookeeper-server-start ~/confluent-7.5.0/etc/kafka/zookeeper.properties &
sleep 10;
nc -zv localhost 2181
exit 0;