#!/bin/bash

~/confluent-7.5.0/bin/schema-registry-start ~/confluent-7.5.0/etc/schema-registry/schema-registry.properties &

~/confluent-7.5.0/bin/kafka-rest-start ~/confluent-7.5.0/etc/kafka-rest/kafka-rest.properties &

~/confluent-7.5.0/bin/ksql-server-start ~/confluent-7.5.0/etc/ksqldb/ksql-server.properties &

~/confluent-7.5.0/bin/connect-standalone ~/confluent-7.5.0/etc/schema-registry/connect-avro-standalone.properties &

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --create --replication-factor 3 --partitions 6

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --list

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --describe

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --alter --partitions 9

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --describe --under-replicated-partitions

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --describe --unavailable-partitions

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --describe --at-min-isr-partitions

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --describe --under-min-isr-partitions

~/confluent-7.5.0/bin/kafka-configs --bootstrap-server localhost:9092 --topic users --alter --add-config 'retention.ms=1000'

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --describe

~/confluent-7.5.0/bin/kafka-configs --bootstrap-server localhost:9092 --topic users --alter --delete-config 'retention.ms'

~/confluent-7.5.0/bin/kafka-topics --bootstrap-server localhost:9092 --topic users --delete

~/confluent-7.5.0/bin/kafka-console-producer --broker-list localhost:9092 --topic users

~/confluent-7.5.0/bin/kafka-console-consumer --bootstrap-server localhost:9092 --topic users --from-beginning