#!/bin/bash
~/confluent-7.3.4/bin/kafka-server-stop
sleep 10;
~/confluent-7.3.4/bin/kafka-server-start ~/confluent-7.3.4/etc/kafka/server.properties &
sleep 10;
nc -zv localhost 9092
exit 0;
