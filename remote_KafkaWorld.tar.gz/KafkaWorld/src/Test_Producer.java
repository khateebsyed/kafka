import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;

public class Test_Producer {

    public static void main(String[] args) {

        System.out.println("Creating Kafka Producer...");
        Properties props = new Properties();
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "producer-1");
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "broker-01:9092,broker-02:9092,broker-03:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        KafkaProducer<Integer, String> producer = new KafkaProducer<>(props);

        System.out.println("### Producing messages ###");
        for (int i = 1; i <= 500; i++) {
            producer.send(new ProducerRecord<>("users", i, "New-IntelliJ-" + i));
        }

        System.out.println("### Closing producer ###");
        producer.close();

    }
}